main() {
  print('Olá Dart!');
  print("Até o próximo exercício!!!");
}
